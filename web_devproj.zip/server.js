const { v4: uuidv4 } = require('uuid');
var moment = require('moment'); // require
var express = require('express')
var app = express()
app.use(express.json());

quotes = {
    list : [

//insert quotes here
"Imagination is more important than knowledge. -Albert Einstien",
"The greatest glory in living lies not in never falling, but in rising every time we fall. -Nelson Mandela",
"The way to get started is to quit talking and begin doing. -Walt Disney",
"Your time is limited, so don't waste it living someone else's life. Don't be trapped by dogma – which is living with the results of other people's thinking. -Steve Jobs",
"If life were predictable it would cease to be life, and be without flavor. -Eleanor Roosevelt",
"If you look at what you have in life, you'll always have more. If you look at what you don't have in life, you'll never have enough. -Oprah Winfrey",
"If you set your goals ridiculously high and it's a failure, you will fail above everyone else's success. -James Cameron",
"Life is what happens when you're busy making other plans. -John Lennon",
"Spread love everywhere you go. Let no one ever come to you without leaving happier. -Mother Teresa",
"When you reach the end of your rope, tie a knot in it and hang on. -Franklin D. Roosevelt",
"Always remember that you are absolutely unique. Just like everyone else. -Margaret Mead",
"Don't judge each day by the harvest you reap but by the seeds that you plant. -Robert Louis Stevenson",
"The future belongs to those who believe in the beauty of their dreams. -Eleanor Roosevelt",
"Tell me and I forget. Teach me and I remember. Involve me and I learn. -Benjamin Franklin",
"The best and most beautiful things in the world cannot be seen or even touched - they must be felt with the heart. -Helen Keller",
"It is during our darkest moments that we must focus to see the light. -Aristotle",
"Whoever is happy will make others happy too. -Anne Frank",
"Do not go where the path may lead, go instead where there is no path and leave a trail. -Ralph Waldo Emerson",
"You will face many defeats in life, but never let yourself be defeated. -Maya Angelou",
"The greatest glory in living lies not in never falling, but in rising every time we fall. -Nelson Mandela",
"In the end, it's not the years in your life that count. It's the life in your years. -Abraham Lincoln",
"Never let the fear of striking out keep you from playing the game. -Babe Ruth",
"Life is either a daring adventure or nothing at all. -Helen Keller",
"Many of life's failures are people who did not realize how close they were to success when they gave up. -Thomas A. Edison",
"You have brains in your head. You have feet in your shoes. You can steer yourself any direction you choose. -Dr. Seuss",
"If life were predictable it would cease to be life and be without flavor. -Eleanor Roosevelt",
"In the end, it's not the years in your life that count. It's the life in your years. -Abraham Lincoln",
"Life is a succession of lessons which must be lived to be understood. -Ralph Waldo Emerson",
"You will face many defeats in life, but never let yourself be defeated. -Maya Angelou",
"Success is not final; failure is not fatal: It is the courage to continue that counts. -Winston S. Churchill",
"Success usually comes to those who are too busy to be looking for it. -Henry David Thoreau",
"The way to get started is to quit talking and begin doing. -Walt Disney",
"If you really look closely, most overnight successes took a long time. -Steve Jobs",
"The secret of success is to do the common thing uncommonly well. -John D. Rockefeller Jr.",
"I find that the harder I work, the more luck I seem to have. -Thomas Jefferson",
"The real test is not whether you avoid this failure, because you won't. It's whether you let it harden or shame you into inaction, or whether you learn from it; whether you choose to persevere. -Barack Obama",
"Dream big and dare to fail. -Norman Vaughan",
"You may be disappointed if you fail, but you are doomed if you don't try. -Beverly Sills",
"Life is 10% what happens to me and 90% of how I react to it. -Charles Swindoll",
"Nothing is impossible, the word itself says, ‘I'm possible!' -Audrey Hepburn",
"It does not matter how slowly you go as long as you do not stop. -Confucius",
"When everything seems to be going against you, remember that the airplane takes off against the wind, not with it. -Henry Ford",
"Too many of us are not living our dreams because we are living our fears. -Les Brown",
"I would rather die of passion than of boredom. -Vincent van Gogh",
"Whatever the mind of man can conceive and believe, it can achieve. -Napoleon Hill",
"You miss 100% of the shots you don't take. -Wayne Gretzky",
"Whether you think you can or you think you can't, you're right. -Henry Ford",
"I have learned over the years that when one's mind is made up, this diminishes fear. -Rosa Parks",
"I alone cannot change the world, but I can cast a stone across the water to create many ripples. -Mother Teresa",
"Nothing is impossible, the word itself says, ‘I'm possible!' -Audrey Hepburn",
"The question isn't who is going to let me; it's who is going to stop me. -Ayn Rand",
"The only person you are destined to become is the person you decide to be. -Ralph Waldo Emerson",
"Be yourself; everyone else is already taken. - Oscar Wilde",


    ]
}

loginInfo = {
   
}

apiInfo = {
    

}

apiUsage = {
   
}

app.get('/', function (req, res, next) {
    res.sendFile(__dirname + '/html/user.html');
})



app.post('/login', function (req, res, next) {

    var username = req.body.username
    var password = req.body.password

    if(loginInfo[username] == password){
   
        var weekNum = moment().week()   
        quoteJson = {
            // replace with weeknum when all qoutes are in
            "quote" : quotes.list[weekNum-1],
            "key": apiInfo[username],
            "usage": apiUsage[apiInfo[username]]
        }
      
        console.log(JSON.stringify(quoteJson))
        res.send(JSON.stringify(quoteJson))
    }else{
        errorJson = {
            "error" : "Wrong Username/Password"
        }
        res.send(JSON.stringify(errorJson))

    }


})


app.post('/reg', function (req, res, next) {

    var username = req.body.username
    var password = req.body.password
    loginInfo[username] = password

    var key = uuidv4()
    apiInfo[username] = key
    apiUsage[key] = 0

    temp = {
        "res":"okay"
    }

    res.send(JSON.stringify(temp))


})


app.post('/checkusage', function (req, res, next) {

    var key = req.body.key
    if(key in apiUsage){

        // 10 uses
       
            temp = {
                "res": apiUsage[key]
            }
            res.send(JSON.stringify(temp))

       

    }else{
        temp = {
            "res":"Invalid Key"
        }
    
        res.send(JSON.stringify(temp))

    }


  


})

app.post('/qoutesapi', function (req, res, next) {

    var key = req.body.key
    var date = req.body.date
    console.log(apiInfo)
    if(key in apiUsage){

        // 10 uses
        if(apiUsage[key] > 9){
            temp = {
                "res":"Key Usage Exceeded"
            }
            res.send(JSON.stringify(temp))
        }else{
            console.log(date)
            dayOfTheWeek = moment(date)
            console.log(dayOfTheWeek.format('w'));
            apiUsage[key] = apiUsage[key] + 1
            temp = {
                // replace with day of the week when all qoutes are in
                "res": quotes.list[dayOfTheWeek.format('w')],
                "usage" : apiUsage[key]
            }
            console.log(temp)
            
            res.send(JSON.stringify(temp))

        }
       

    }else{
        temp = {
            "res":"Invalid Key",
            "usage" : apiUsage[key]
        }
    
        res.send(JSON.stringify(temp))

    }

   

  

    


})

app.listen(80);
